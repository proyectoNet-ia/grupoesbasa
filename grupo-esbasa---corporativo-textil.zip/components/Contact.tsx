
import React, { useState } from 'react';

interface FormState {
  name: string;
  email: string;
  phone: string;
  message: string;
  captcha: boolean;
}

interface FormErrors {
  name?: string;
  email?: string;
  phone?: string;
  message?: string;
}

const Contact: React.FC = () => {
  const [formData, setFormData] = useState<FormState>({
    name: '',
    email: '',
    phone: '',
    message: '',
    captcha: false,
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const socialLinks = [
    { id: 'facebook-f', name: 'Facebook' },
    { id: 'instagram', name: 'Instagram' },
    { id: 'linkedin-in', name: 'LinkedIn' }
  ];

  const validate = (): boolean => {
    const newErrors: FormErrors = {};
    if (!formData.name.trim()) newErrors.name = 'El nombre es requerido';
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email) newErrors.email = 'El correo es requerido';
    else if (!emailRegex.test(formData.email)) newErrors.email = 'Formato no válido';
    const phoneRegex = /^\+?[0-9\s-]{10,15}$/;
    if (!formData.phone) newErrors.phone = 'El teléfono es requerido';
    else if (!phoneRegex.test(formData.phone)) newErrors.phone = 'Mínimo 10 dígitos';
    if (!formData.message.trim()) newErrors.message = 'Por favor describe tu requerimiento';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const val = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setFormData(prev => ({ ...prev, [name]: val }));
    if (errors[name as keyof FormErrors]) setErrors(prev => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      setIsSubmitting(true);
      await new Promise(resolve => setTimeout(resolve, 1500));
      setIsSubmitting(false);
      setSubmitSuccess(true);
      setFormData({ name: '', email: '', phone: '', message: '', captcha: false });
      setTimeout(() => setSubmitSuccess(false), 5000);
    }
  };

  return (
    <div className="py-20 md:py-32 bg-blue-50/30">
      <div className="container mx-auto px-6">
        <div 
          className="bg-white rounded-[2rem] md:rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col lg:flex-row border border-blue-100 mb-12"
          data-aos="fade-up"
        >
          <div className="lg:w-1/3 bg-blue-950 p-10 md:p-14 text-white relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/10 rounded-bl-full"></div>
            <h2 className="text-2xl md:text-3xl font-black mb-10 relative z-10">Contacto Directo</h2>
            
            <div className="space-y-8 relative z-10">
              <div className="flex items-center gap-5 group cursor-pointer">
                <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-red-600 transition-colors">
                  <i className="fa-solid fa-location-dot text-red-500 group-hover:text-white"></i>
                </div>
                <div>
                  <p className="text-blue-300 text-[10px] uppercase font-bold tracking-widest mb-1">Ubicación</p>
                  <p className="text-sm font-medium">Estado de México, MX.</p>
                </div>
              </div>
              <div className="flex items-center gap-5 group cursor-pointer">
                <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-red-600 transition-colors">
                  <i className="fa-solid fa-phone text-red-500 group-hover:text-white"></i>
                </div>
                <div>
                  <p className="text-blue-300 text-[10px] uppercase font-bold tracking-widest mb-1">Teléfono</p>
                  <p className="text-sm font-medium">+52 (55) 5892-1234</p>
                </div>
              </div>
              <div className="flex items-center gap-5 group cursor-pointer">
                <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-red-600 transition-colors">
                  <i className="fa-solid fa-envelope text-red-500 group-hover:text-white"></i>
                </div>
                <div>
                  <p className="text-blue-300 text-[10px] uppercase font-bold tracking-widest mb-1">Email</p>
                  <p className="text-sm font-medium">ventas@grupoesbasa.com</p>
                </div>
              </div>
            </div>

            <div className="mt-20 pt-10 border-t border-white/10">
              <p className="text-[10px] uppercase font-black tracking-[0.2em] mb-4 text-blue-300/60">Síguenos</p>
              <div className="flex gap-4">
                {socialLinks.map((social) => (
                  <div key={social.id} className="w-10 h-10 border border-white/20 rounded-full flex items-center justify-center text-white cursor-pointer hover:bg-red-600 transition-all hover:-translate-y-1">
                    <i className={`fa-brands fa-${social.id} text-xs`}></i>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:w-2/3 p-8 md:p-14">
            <h2 className="text-2xl md:text-3xl font-black text-blue-950 mb-3 tracking-tight">Solicitar Cotización</h2>
            <p className="text-blue-900/50 mb-10 text-sm font-medium">Completa el formulario y un asesor experto te contactará.</p>
            
            {submitSuccess && (
              <div className="mb-8 p-4 bg-green-50 border border-green-200 text-green-700 rounded-xl text-sm font-bold flex items-center gap-3 animate-pulse">
                <i className="fa-solid fa-circle-check text-lg"></i>
                ¡Mensaje enviado con éxito! Te contactaremos pronto.
              </div>
            )}

            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-blue-400">Nombre Completo *</label>
                <input 
                  type="text" 
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className={`w-full px-5 py-3.5 bg-blue-50/30 border ${errors.name ? 'border-red-400' : 'border-blue-100'} rounded-xl outline-none text-sm font-medium focus:bg-white focus:ring-2 focus:ring-blue-100 transition-all`} 
                  placeholder="Ej. Juan Pérez" 
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-blue-400">Email Corporativo *</label>
                <input 
                  type="email" 
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`w-full px-5 py-3.5 bg-blue-50/30 border ${errors.email ? 'border-red-400' : 'border-blue-100'} rounded-xl outline-none text-sm font-medium focus:bg-white focus:ring-2 focus:ring-blue-100 transition-all`} 
                  placeholder="empresa@correo.com" 
                />
              </div>

              <div className="md:col-span-2 space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-blue-400">Teléfono / WhatsApp *</label>
                <input 
                  type="tel" 
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className={`w-full px-5 py-3.5 bg-blue-50/30 border ${errors.phone ? 'border-red-400' : 'border-blue-100'} rounded-xl outline-none text-sm font-medium focus:bg-white focus:ring-2 focus:ring-blue-100 transition-all`} 
                  placeholder="+52 55 1234 5678" 
                />
              </div>

              <div className="md:col-span-2 space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-blue-400">Mensaje o Requerimiento *</label>
                <textarea 
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4} 
                  className={`w-full px-5 py-3.5 bg-blue-50/30 border ${errors.message ? 'border-red-400' : 'border-blue-100'} rounded-xl outline-none text-sm font-medium resize-none focus:bg-white focus:ring-2 focus:ring-blue-100 transition-all`} 
                  placeholder="¿En qué podemos ayudarte?" 
                />
              </div>

              <div className="md:col-span-2 pt-4">
                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className={`w-full py-4 ${isSubmitting ? 'bg-blue-300' : 'bg-blue-950 hover:bg-red-600'} text-white font-bold rounded-xl shadow-xl transition-all uppercase tracking-widest text-xs flex items-center justify-center gap-3 active:scale-95`}
                >
                  {isSubmitting ? <i className="fa-solid fa-spinner animate-spin"></i> : 'Enviar Solicitud'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
